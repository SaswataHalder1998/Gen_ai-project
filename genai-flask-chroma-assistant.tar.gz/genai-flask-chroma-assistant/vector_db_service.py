"""
Vector Database Service using ChromaDB
Handles storage, retrieval and management of document embeddings.
"""

import chromadb
from chromadb.config import Settings
from typing import List, Dict, Tuple
import os
from config import Config


class VectorDBService:
    """Service for managing ChromaDB vector database."""

    def __init__(self):
        """Initialize ChromaDB with persistent storage."""
        os.makedirs(Config.CHROMA_PERSIST_DIR, exist_ok=True)

        settings = Settings(
            is_persistent=True,
            persist_directory=Config.CHROMA_PERSIST_DIR,
            anonymized_telemetry=False
        )

        print(f"🔄 Initializing ChromaDB from {Config.CHROMA_PERSIST_DIR}...")
        self.client = chromadb.Client(settings)

        self.collection = self.client.get_or_create_collection(
            name=Config.CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )
        print(f"✓ ChromaDB initialized, collection: {Config.CHROMA_COLLECTION_NAME}")

    def add_documents(self, documents: List[str], metadatas: List[Dict] = None, ids: List[str] = None):
        """
        Add documents to the vector database.

        Args:
            documents: List of document texts
            metadatas: Optional list of metadata dicts
            ids: Optional list of document IDs
        """
        if not ids:
            ids = [f"doc_{i}" for i in range(len(documents))]

        if not metadatas:
            metadatas = [{"source": "training"} for _ in documents]

        self.collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        print(f"✓ Added {len(documents)} documents to ChromaDB")

    def search(self, query_embedding: List[float], top_k: int = None) -> Tuple[List[str], List[Dict], List[float]]:
        """
        Search for similar documents using semantic similarity.

        Args:
            query_embedding: Query embedding vector
            top_k: Number of top results to return

        Returns:
            Tuple of (documents, metadatas, distances)
        """
        top_k = top_k or Config.CHROMA_TOP_K

        results = self.collection.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=top_k,
            include=["documents", "metadatas", "distances"]
        )

        documents = results["documents"][0] if results["documents"] else []
        metadatas = results["metadatas"][0] if results["metadatas"] else []
        distances = results["distances"][0] if results["distances"] else []

        # Convert distances to similarity scores (cosine similarity: 1 - distance)
        similarities = [1 - d for d in distances]

        return documents, metadatas, similarities

    def get_collection_count(self) -> int:
        """Get number of documents in collection."""
        return self.collection.count()

    def delete_all(self):
        """Delete all documents from collection."""
        self.client.delete_collection(name=Config.CHROMA_COLLECTION_NAME)
        self.collection = self.client.get_or_create_collection(
            name=Config.CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )
        print("✓ All documents deleted from ChromaDB")
