"""
RAG (Retrieval-Augmented Generation) Engine
Orchestrates embedding generation, vector search, and LLM calling.
"""

from typing import Dict, List, Tuple
from embedding_service import EmbeddingService
from vector_db_service import VectorDBService
from llm_service import LLMService, LLMError
from config import Config


class RAGEngine:
    """Main RAG orchestration engine."""

    def __init__(self):
        """Initialize RAG engine components."""
        self.embedding_service = EmbeddingService()
        self.vector_db = VectorDBService()
        self.llm_service = LLMService()

    def initialize_knowledge_base(self, documents: List[str], document_ids: List[str] = None):
        """
        Initialize knowledge base with documents.

        Args:
            documents: List of knowledge base documents
            document_ids: Optional list of document IDs
        """
        if not documents:
            raise ValueError("No documents provided")

        print(f"\n🔄 Initializing knowledge base with {len(documents)} documents...")

        # Generate embeddings for documents
        embeddings = self.embedding_service.embed_documents(documents)

        # Prepare metadatas
        metadatas = [
            {
                "document_id": document_ids[i] if document_ids else f"doc_{i}",
                "source": "genai-training",
                "embedding_model": Config.EMBEDDING_MODEL
            }
            for i in range(len(documents))
        ]

        # Add to vector DB
        doc_ids = document_ids or [f"doc_{i}" for i in range(len(documents))]
        self.vector_db.add_documents(documents, metadatas, doc_ids)

        print(f"✓ Knowledge base initialized with {self.vector_db.get_collection_count()} documents")

    def retrieve_context(self, query: str, top_k: int = None) -> Tuple[List[str], List[Dict], List[float]]:
        """
        Retrieve relevant context from vector DB.

        Args:
            query: User query
            top_k: Number of top results

        Returns:
            Tuple of (documents, metadatas, similarities)
        """
        top_k = top_k or Config.CHROMA_TOP_K

        # Generate query embedding
        query_embedding = self.embedding_service.embed_query(query)

        # Search vector DB
        documents, metadatas, similarities = self.vector_db.search(query_embedding, top_k)

        # Filter by similarity threshold
        filtered_results = [
            (doc, meta, sim)
            for doc, meta, sim in zip(documents, metadatas, similarities)
            if sim >= Config.CHROMA_SIMILARITY_THRESHOLD
        ]

        if not filtered_results:
            print(f"⚠️  No documents found above similarity threshold ({Config.CHROMA_SIMILARITY_THRESHOLD})")
            return [], [], []

        documents, metadatas, similarities = zip(*filtered_results)
        return list(documents), list(metadatas), list(similarities)

    def generate_rag_prompt(self, query: str, context_docs: List[str]) -> str:
        """
        Generate prompt with context for RAG.

        Args:
            query: User query
            context_docs: Retrieved context documents

        Returns:
            Formatted prompt with persona, context, task and constraints
        """
        context_text = "\n".join([f"- {doc}" for doc in context_docs])

        prompt = f"""Based on the following context, answer the user's question about GenAI.

CONTEXT:
{context_text}

USER QUESTION:
{query}

Please provide a clear, beginner-friendly answer based on the context above. If the context doesn't contain relevant information, provide a general answer based on your knowledge."""

        return prompt

    def query(self, user_query: str, top_k: int = None) -> Dict:
        """
        Execute full RAG pipeline: retrieve context and generate answer.

        Args:
            user_query: User's question
            top_k: Number of context documents to retrieve

        Returns:
            Dict with query, context, similarities, answer, and metadata
        """
        result = {
            "query": user_query,
            "context_documents": [],
            "context_metadatas": [],
            "similarities": [],
            "answer": None,
            "error": None,
            "status": "pending"
        }

        try:
            # Step 1: Retrieve relevant context
            print(f"\n📚 Retrieving context for query: '{user_query}'")
            documents, metadatas, similarities = self.retrieve_context(user_query, top_k)

            result["context_documents"] = documents
            result["context_metadatas"] = metadatas
            result["similarities"] = similarities

            if not documents:
                print("⚠️  No relevant context found")
                result["status"] = "no_context"
                return result

            print(f"✓ Retrieved {len(documents)} relevant documents")

            # Step 2: Generate RAG prompt
            rag_prompt = self.generate_rag_prompt(user_query, documents)

            # Step 3: Call LLM
            print(f"🤖 Generating answer using LLM...")
            api_response = self.llm_service.call_llm(rag_prompt)

            if not api_response:
                raise LLMError("Empty response from LLM")

            answer = self.llm_service.extract_response(api_response)
            if not answer:
                raise LLMError("Could not extract answer from LLM response")

            result["answer"] = answer
            result["status"] = "success"
            print(f"✓ Answer generated successfully")

        except LLMError as e:
            result["error"] = str(e)
            result["status"] = "llm_error"
            print(f"❌ LLM Error: {str(e)}")
        except Exception as e:
            result["error"] = f"Unexpected error: {str(e)}"
            result["status"] = "error"
            print(f"❌ Error: {str(e)}")

        return result
