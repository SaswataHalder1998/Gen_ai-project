"""
LLM Service for API integration with error handling
Handles REST API calls to Claude/LLM endpoints with proper error handling.
"""

import requests
from typing import Optional, Dict
import json
from config import Config


class LLMError(Exception):
    """Custom exception for LLM-related errors."""
    pass


class LLMService:
    """Service for calling LLM API with proper error handling."""

    def __init__(self):
        """Initialize LLM service with configuration."""
        if not Config.ANTHROPIC_API_KEY:
            raise LLMError("ANTHROPIC_API_KEY not found in environment variables")

        self.api_key = Config.ANTHROPIC_API_KEY
        self.endpoint = Config.LLM_ENDPOINT
        self.model = Config.LLM_MODEL
        self.headers = Config.get_llm_headers()
        self.timeout = Config.LLM_TIMEOUT

    def call_llm(
        self,
        user_message: str,
        system_prompt: str = None,
        temperature: float = None,
        max_tokens: int = None
    ) -> Optional[Dict]:
        """
        Call LLM API with error handling.

        Args:
            user_message: User query/prompt
            system_prompt: System instruction
            temperature: Model temperature (0-1)
            max_tokens: Maximum tokens in response

        Returns:
            Full response JSON or None on error
        """
        temperature = temperature or Config.LLM_TEMPERATURE
        max_tokens = max_tokens or Config.LLM_MAX_TOKENS
        system_prompt = system_prompt or self._get_default_system_prompt()

        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": user_message}
            ]
        }

        try:
            print(f"📤 Calling LLM API: {self.endpoint}")
            response = requests.post(
                self.endpoint,
                json=payload,
                headers=self.headers,
                timeout=self.timeout
            )

            # Handle HTTP errors
            if response.status_code == 401:
                raise LLMError("Authentication failed (401): Invalid API key. Check ANTHROPIC_API_KEY in .env")
            elif response.status_code == 404:
                raise LLMError("Not found (404): Check LLM_ENDPOINT in .env")
            elif response.status_code == 405:
                raise LLMError("Method not allowed (405): Check request format")
            elif response.status_code >= 400:
                raise LLMError(f"HTTP {response.status_code}: {response.text}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.ConnectionError as e:
            raise LLMError(f"Connection error: Could not reach {self.endpoint}. Check endpoint URL.")
        except requests.exceptions.Timeout as e:
            raise LLMError(f"Timeout error: Request took longer than {self.timeout}s")
        except json.JSONDecodeError as e:
            raise LLMError(f"Invalid JSON response from API: {e}")
        except Exception as e:
            raise LLMError(f"Unexpected error calling LLM: {str(e)}")

    def extract_response(self, api_response: Dict) -> Optional[str]:
        """Extract assistant message from API response."""
        try:
            if "choices" in api_response and len(api_response["choices"]) > 0:
                return api_response["choices"][0].get("message", {}).get("content")
        except (KeyError, TypeError, IndexError):
            pass
        return None

    def _get_default_system_prompt(self) -> str:
        """Get default system prompt for GenAI assistant."""
        return """You are a knowledgeable GenAI and LLM assistant helping beginners understand AI concepts.

Your role:
- Provide clear, beginner-friendly explanations
- Use simple language and avoid overly technical jargon
- Provide practical examples when relevant
- Be concise but comprehensive

When answering:
1. Start with a brief definition
2. Explain the concept simply
3. Provide 2-3 key points
4. Include a practical example if relevant
5. Keep response to 3-4 sentences maximum"""
