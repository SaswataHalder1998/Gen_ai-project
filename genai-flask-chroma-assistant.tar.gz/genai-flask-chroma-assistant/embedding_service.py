"""
Embedding service using Sentence Transformers
Handles generation of embeddings for queries and documents.
"""

from sentence_transformers import SentenceTransformer
from typing import List, Union
import numpy as np
from config import Config


class EmbeddingService:
    """Service for generating text embeddings."""

    def __init__(self, model_name: str = None):
        """Initialize embedding service with specified model."""
        self.model_name = model_name or Config.EMBEDDING_MODEL
        print(f"🔄 Loading embedding model: {self.model_name}...")
        self.model = SentenceTransformer(self.model_name)
        print(f"✓ Embedding model loaded successfully")

    def embed_text(self, text: Union[str, List[str]]) -> Union[np.ndarray, List[np.ndarray]]:
        """
        Generate embeddings for text(s).

        Args:
            text: Single text string or list of text strings

        Returns:
            Embeddings as numpy array or list of arrays
        """
        return self.model.encode(text)

    def embed_query(self, query: str) -> np.ndarray:
        """Generate embedding for a single query."""
        return self.embed_text(query)

    def embed_documents(self, documents: List[str]) -> List[np.ndarray]:
        """Generate embeddings for multiple documents."""
        return [self.embed_text(doc) for doc in documents]

    def get_embedding_dimension(self) -> int:
        """Get the dimension of embeddings."""
        return self.model.get_sentence_embedding_dimension()
