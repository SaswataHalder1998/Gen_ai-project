"""
Configuration management for GenAI Knowledge Assistant
Loads and validates environment variables with secure defaults.
"""

import os
from dotenv import load_dotenv
from typing import Optional

load_dotenv(override=True)


class Config:
    """Base configuration class."""

    # Flask
    FLASK_ENV = os.getenv("FLASK_ENV", "production")
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    SECRET_KEY = os.getenv("SECRET_KEY", os.urandom(24).hex())

    # LLM Configuration
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
    LLM_ENDPOINT = os.getenv("LLM_ENDPOINT", "https://llmgw-wp.tekstac.com/v1/chat/completions")
    LLM_MODEL = os.getenv("LLM_MODEL", "global.anthropic.claude-haiku-4-5-20251001-v1:0")
    LLM_API_VERSION = os.getenv("LLM_API_VERSION", "2023-06-01")
    LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "512"))
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.5"))
    LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "30"))

    # Embedding Configuration
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    EMBEDDING_DIMENSION = int(os.getenv("EMBEDDING_DIMENSION", "384"))

    # ChromaDB Configuration
    CHROMA_COLLECTION_NAME = os.getenv("CHROMA_COLLECTION_NAME", "genai-knowledge-base")
    CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma_db")
    CHROMA_TOP_K = int(os.getenv("CHROMA_TOP_K", "3"))
    CHROMA_SIMILARITY_THRESHOLD = float(os.getenv("CHROMA_SIMILARITY_THRESHOLD", "0.3"))

    # RAG Configuration
    RAG_CONTEXT_WINDOW = int(os.getenv("RAG_CONTEXT_WINDOW", "2000"))
    RAG_MAX_CHUNKS = int(os.getenv("RAG_MAX_CHUNKS", "5"))

    @classmethod
    def validate(cls) -> bool:
        """Validate critical configuration."""
        if not cls.ANTHROPIC_API_KEY:
            print("⚠️  Warning: ANTHROPIC_API_KEY not set in .env file")
            return False
        return True

    @classmethod
    def get_llm_headers(cls) -> dict:
        """Get LLM API headers."""
        return {
            "x-api-key": cls.ANTHROPIC_API_KEY,
            "anthropic-version": cls.LLM_API_VERSION,
            "content-type": "application/json"
        }
