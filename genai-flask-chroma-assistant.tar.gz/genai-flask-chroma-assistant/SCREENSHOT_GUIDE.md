# How to Take 3 Screenshots - Manual Guide

## Prerequisites
- Flask app running on `http://localhost:5000`
- Modern web browser (Chrome, Firefox, Safari, Edge)

---

## Screenshot 1: Application Running Successfully

### Steps:
1. **Start the Flask Application**
   ```bash
   source /Software/langenv/bin/activate
   python app.py
   ```
   
   Expected output:
   ```
   ============================================================
   🚀 GenAI Knowledge Assistant starting...
   ============================================================
   📍 Endpoint: http://localhost:5000
   🤖 LLM Model: global.anthropic.claude-haiku-4-5-20251001-v1:0
   🧠 Embedding Model: all-MiniLM-L6-v2
   💾 Knowledge Base: 12 documents
   ============================================================
   ```

2. **Open Browser** → Navigate to `http://localhost:5000`

3. **Screenshot the Main UI** showing:
   - ✅ Header: "🤖 GenAI Knowledge Assistant"
   - ✅ Subtitle: "Ask questions about GenAI, LLMs, Embeddings, and RAG"
   - ✅ Knowledge base stat: "📚 Knowledge Base: 12 documents"
   - ✅ Query input textarea with placeholder
   - ✅ Character counter (0/500)
   - ✅ "🚀 Ask Assistant" submit button
   - ✅ Sample questions buttons below
   - ✅ Footer credit

### What This Shows:
- Application is running and accessible
- UI is fully loaded with all components
- Knowledge base initialized with 12 documents
- Ready for user input

---

## Screenshot 2: Retrieved ChromaDB Context

### Steps:
1. **In the browser on the Flask UI** (from Screenshot 1):
   - Click on a sample question button, for example:
     **"What are embeddings?"**
   
   OR manually type in the textarea:
   - Input: `What are embeddings in GenAI?`

2. **Click "🚀 Ask Assistant" button**

3. **Wait for results to load** (should take 2-3 seconds)

4. **Screenshot the Results Section** showing:
   - ✅ **📝 Your Question Card**
     - Displays: "What are embeddings in GenAI?"
   
   - ✅ **📚 Retrieved Context Card** (THIS IS THE KEY SCREENSHOT)
     - Badge showing: "1" (number of documents retrieved)
     - Context items showing:
       ```
       Embeddings are numerical vector representations that capture 
       the semantic meaning of text. They convert words or sentences 
       into high-dimensional vectors that machines can understand 
       and compare.
       ```
     - Metadata line: "Document 1"
     - **Similarity Score:** `Similarity: 0.4560` (cosine similarity)

### What This Shows:
- ChromaDB successfully retrieved matching documents
- Vector similarity search working (0.4560 score means 45.6% similar)
- Retrieved context is relevant to the query
- Top-k retrieval functional (showing top matching document)

---

## Screenshot 3: LLM-Generated Response

### Steps:
1. **Continue from Screenshot 2** (same query results page)

2. **Scroll down** to see the full results page

3. **Screenshot the Answer Section** showing:
   - ✅ **🤖 Assistant Response Card** (THIS IS THE KEY SCREENSHOT)
     - Heading: "🤖 Assistant Response"
     - Full generated answer from Claude LLM:
       ```
       Embeddings are numerical "fingerprints" that convert words 
       or text into numbers that AI can understand and work with.
       
       Think of it this way: if you wanted a computer to understand 
       that "dog" and "puppy" are related concepts, you can't just 
       feed it the words directly. Embeddings solve this by turning 
       text into lists of numbers (vectors) that capture meaning...
       ```
   
   - ✅ **ℹ️ Details Card** (below answer)
     - Status: `Success`
     - Context Chunks: `1`
     - Timestamp: `15:29:28` (current time)
     - Retrieval Method: `Cosine Similarity`

### What This Shows:
- LLM API call successful
- Answer generated based on retrieved context
- Response is beginner-friendly and well-structured
- Integration complete: retrieval → LLM generation → display

---

## Alternative: Using cURL (Command Line)

If you prefer command-line screenshots (copy/paste output):

### Screenshot 2 Example (Retrieved Context):
```bash
curl -s -X POST http://localhost:5000/api/query \
  -H "Content-Type: application/json" \
  -d '{"query":"What are embeddings in GenAI?"}' | jq '{
    query: .query,
    context_count: .context.count,
    context_documents: .context.documents,
    similarity_scores: .context.similarities
}'
```

**Output:**
```json
{
  "query": "What are embeddings in GenAI?",
  "context_count": 1,
  "context_documents": [
    "Embeddings are numerical vector representations that capture the semantic meaning of text..."
  ],
  "similarity_scores": [
    "0.4560"
  ]
}
```

### Screenshot 3 Example (LLM Response):
```bash
curl -s -X POST http://localhost:5000/api/query \
  -H "Content-Type: application/json" \
  -d '{"query":"What are embeddings in GenAI?"}' | jq '{
    query: .query,
    answer: .answer,
    status: .status,
    timestamp: .timestamp
}'
```

**Output:**
```json
{
  "query": "What are embeddings in GenAI?",
  "answer": "Embeddings are numerical \"fingerprints\" that convert words or text into numbers that AI can understand...",
  "status": "success",
  "timestamp": "2026-06-25T15:29:28.002569"
}
```

---

## Full API Response Example

**Complete response showing all components:**

```bash
curl -s -X POST http://localhost:5000/api/query \
  -H "Content-Type: application/json" \
  -d '{"query":"What are embeddings in GenAI?"}' | jq .
```

**Response:**
```json
{
  "query": "What are embeddings in GenAI?",
  "status": "success",
  "timestamp": "2026-06-25T15:29:28.002569",
  "context": {
    "documents": [
      "Embeddings are numerical vector representations that capture the semantic meaning of text. They convert words or sentences into high-dimensional vectors that machines can understand and compare."
    ],
    "similarities": [
      "0.4560"
    ],
    "count": 1
  },
  "answer": "Embeddings are numerical \"fingerprints\" that convert words or text into numbers that AI can understand and work with. Think of it this way: if you wanted a computer to understand that \"dog\" and \"puppy\" are related concepts, you can't just feed it the words directly. Embeddings solve this by turning text into lists of numbers (vectors) that capture meaning. Words with similar meanings end up with similar number patterns.\n\n**Key points:**\n- They transform text into mathematical representations machines can compare and analyze\n- Similar words get similar embeddings, helping AI understand relationships\n- They're the foundation for many GenAI tasks like search, recommendations, and language understanding\n\n**Practical example:** When you use a search engine and search for \"comfortable shoes,\" it finds results about \"cozy footwear\" too—that's embeddings working behind the scenes, recognizing these phrases mean similar things even though the words are different.",
  "error": null
}
```

---

## Sample Queries to Try

For variety in your screenshots, try these questions:

1. **"What are embeddings in GenAI?"** ← Best for basic example
2. **"How does RAG improve LLM responses?"** ← Shows retrieval process
3. **"What is semantic search?"** ← Shows vector similarity
4. **"Explain prompt engineering for beginners"** ← Shows LLM capability
5. **"What role do transformers play in LLMs?"** ← Shows knowledge integration

---

## RAG Flow Demonstrated in Screenshots

### Screenshot 1: Application Ready
- ✅ UI loaded
- ✅ Knowledge base initialized (12 docs)
- ✅ Ready for queries

### Screenshot 2: Context Retrieved
- ✅ Query sent to Flask backend
- ✅ SentenceTransformer generates embedding
- ✅ ChromaDB searches with cosine similarity
- ✅ Top document retrieved with 0.4560 similarity score
- ✅ Context displayed in UI

### Screenshot 3: LLM Response
- ✅ RAG prompt created with retrieved context
- ✅ Claude API called with context + query
- ✅ LLM generates beginner-friendly answer
- ✅ Answer displayed in UI with metadata

---

## Verification Checklist

### Screenshot 1 (Application Running)
- [ ] Page title shows "GenAI Knowledge Assistant"
- [ ] Header displays knowledge base size
- [ ] Query input textarea visible
- [ ] Sample question buttons present
- [ ] No error messages
- [ ] Browser address bar shows `localhost:5000`

### Screenshot 2 (Retrieved Context)
- [ ] "📚 Retrieved Context" card visible
- [ ] Context count badge shows number > 0
- [ ] Document text clearly displayed
- [ ] "Document 1" label visible
- [ ] **Similarity score visible** (e.g., "0.4560")
- [ ] Query is displayed above context

### Screenshot 3 (LLM Response)
- [ ] "🤖 Assistant Response" card visible
- [ ] **Answer text clearly displayed** and readable
- [ ] Answer is beginner-friendly
- [ ] **No error messages**
- [ ] Status shows "Success"
- [ ] Timestamp visible in Details card
- [ ] Retrieved context shown above answer (proves RAG flow)

---

## Troubleshooting

### App not responding
```bash
# Check if Flask is running
ps aux | grep "python app.py"

# Restart if needed
pkill -f "python app.py"
source /Software/langenv/bin/activate
python app.py
```

### No context retrieved
- Query might be too different from knowledge base
- Try: "What are embeddings?" or "What is RAG?"
- Similarity threshold is 0.3, so score must be ≥ 0.3

### API Error
- Check `.env` file has `ANTHROPIC_API_KEY` set
- Verify endpoint is accessible
- Check logs for specific error

---

## File References

- **Frontend UI:** [templates/index.html](templates/index.html)
- **API Endpoint:** [app.py:66-107](app.py#L66-L107)
- **RAG Engine:** [rag_engine.py](rag_engine.py)
- **Verification:** [RAG_VERIFICATION.md](RAG_VERIFICATION.md)
