"""
GenAI Knowledge Assistant Flask Application
A production-ready RAG application with ChromaDB and LLM integration.
"""

from flask import Flask, render_template, request, jsonify
from config import Config
from rag_engine import RAGEngine
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = Config.SECRET_KEY
app.config['JSON_SORT_KEYS'] = False

# Global RAG engine
rag_engine = None


# Sample knowledge base for GenAI training
GENAI_KNOWLEDGE_BASE = [
    "Embeddings are numerical vector representations that capture the semantic meaning of text. They convert words or sentences into high-dimensional vectors that machines can understand and compare.",
    "Semantic search compares meaning rather than exact keywords. It uses embeddings to find documents that have similar meaning, even if they use different words.",
    "Vector databases like ChromaDB store embeddings and enable fast similarity searches. They use techniques like HNSW (Hierarchical Navigable Small World) for efficient retrieval.",
    "RAG (Retrieval-Augmented Generation) combines information retrieval with language models. It retrieves relevant context first, then uses that context to generate accurate answers.",
    "Large Language Models (LLMs) like Claude are neural networks trained on vast amounts of text. They can understand context, generate coherent responses, and perform complex reasoning tasks.",
    "Prompt engineering is the art of crafting effective instructions for LLMs. It involves persona definition, context provision, clear task specification, and constraints.",
    "Transformers are the neural network architecture behind modern LLMs. They use attention mechanisms to process sequences and understand relationships between words.",
    "Temperature controls randomness in LLM outputs. Lower temperature (0-0.3) produces deterministic responses, while higher temperature (0.7-1.0) produces more creative outputs.",
    "Tokens are the basic units of text that LLMs process. One token typically equals 4 characters or 0.75 words in English.",
    "Fine-tuning allows customizing LLMs for specific domains. It involves training on domain-specific data to improve relevance and accuracy for targeted use cases.",
    "Hallucination in LLMs refers to generating plausible-sounding but false information. RAG reduces hallucination by grounding responses in retrieved factual context.",
    "API keys are credentials for accessing LLM services. They should be kept secret and loaded from environment variables, never hard-coded in source code.",
]

KNOWLEDGE_BASE_IDS = [f"genai_concept_{i+1}" for i in range(len(GENAI_KNOWLEDGE_BASE))]


def initialize_rag_engine():
    """Initialize RAG engine with knowledge base."""
    global rag_engine
    try:
        logger.info("Initializing RAG engine...")
        rag_engine = RAGEngine()
        rag_engine.initialize_knowledge_base(GENAI_KNOWLEDGE_BASE, KNOWLEDGE_BASE_IDS)
        logger.info("✓ RAG engine initialized successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize RAG engine: {e}")
        return False


@app.route("/")
def index():
    """Render main page."""
    return render_template("index.html")


@app.route("/api/query", methods=["POST"])
def query_endpoint():
    """API endpoint for handling user queries."""
    try:
        data = request.get_json()
        user_query = data.get("query", "").strip()

        if not user_query:
            return jsonify({"error": "Query cannot be empty"}), 400

        if not rag_engine:
            return jsonify({"error": "RAG engine not initialized"}), 500

        if len(user_query) > 500:
            return jsonify({"error": "Query too long (max 500 characters)"}), 400

        logger.info(f"Processing query: {user_query}")

        # Execute RAG pipeline
        result = rag_engine.query(user_query)

        # Format response
        response = {
            "query": result["query"],
            "status": result["status"],
            "timestamp": datetime.now().isoformat(),
            "context": {
                "documents": result["context_documents"],
                "similarities": [f"{sim:.4f}" for sim in result["similarities"]],
                "count": len(result["context_documents"])
            },
            "answer": result["answer"],
            "error": result["error"]
        }

        status_code = 200 if result["status"] == "success" else 400
        return jsonify(response), status_code

    except Exception as e:
        logger.error(f"Unexpected error in query endpoint: {e}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500


@app.route("/api/health", methods=["GET"])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy" if rag_engine else "initializing",
        "llm_endpoint": Config.LLM_ENDPOINT,
        "embedding_model": Config.EMBEDDING_MODEL,
        "chroma_collection": Config.CHROMA_COLLECTION_NAME,
        "timestamp": datetime.now().isoformat()
    }), 200


@app.route("/api/stats", methods=["GET"])
def get_stats():
    """Get system statistics."""
    try:
        if not rag_engine:
            return jsonify({"error": "RAG engine not initialized"}), 500

        return jsonify({
            "knowledge_base_size": rag_engine.vector_db.get_collection_count(),
            "embedding_dimension": rag_engine.embedding_service.get_embedding_dimension(),
            "embedding_model": Config.EMBEDDING_MODEL,
            "llm_model": Config.LLM_MODEL,
            "chroma_top_k": Config.CHROMA_TOP_K,
            "similarity_threshold": Config.CHROMA_SIMILARITY_THRESHOLD
        }), 200

    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        return jsonify({"error": str(e)}), 500


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(405)
def method_not_allowed(error):
    """Handle 405 errors."""
    return jsonify({"error": "Method not allowed"}), 405


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    logger.error(f"Internal server error: {error}")
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    # Validate configuration
    if not Config.validate():
        print("\n⚠️  Configuration validation failed. Update .env file with valid credentials.")

    # Initialize RAG engine
    if not initialize_rag_engine():
        print("\n❌ Failed to initialize RAG engine. Check configuration and try again.")
        exit(1)

    # Run Flask app
    print(f"\n{'='*60}")
    print(f"🚀 GenAI Knowledge Assistant starting...")
    print(f"{'='*60}")
    print(f"📍 Endpoint: http://localhost:5001")
    print(f"🤖 LLM Model: {Config.LLM_MODEL}")
    print(f"🧠 Embedding Model: {Config.EMBEDDING_MODEL}")
    print(f"💾 Knowledge Base: {rag_engine.vector_db.get_collection_count()} documents")
    print(f"{'='*60}\n")

    app.run(debug=Config.DEBUG, host="0.0.0.0", port=5001)
