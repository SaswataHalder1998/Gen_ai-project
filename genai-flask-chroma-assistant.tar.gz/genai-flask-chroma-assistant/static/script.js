// GenAI Knowledge Assistant - Client-side JavaScript

const API_BASE = '/api';
const ELEMENTS = {
    queryInput: document.getElementById('queryInput'),
    submitBtn: document.getElementById('submitBtn'),
    charCount: document.getElementById('charCount'),
    loadingState: document.getElementById('loadingState'),
    errorState: document.getElementById('errorState'),
    errorMessage: document.getElementById('errorMessage'),
    resultsSection: document.getElementById('resultsSection'),
    samplesSection: document.getElementById('samplesSection'),
    displayedQuery: document.getElementById('displayedQuery'),
    contextContainer: document.getElementById('contextContainer'),
    contextCount: document.getElementById('contextCount'),
    assistantAnswer: document.getElementById('assistantAnswer'),
    metadataContainer: document.getElementById('metadataContainer'),
    kbSize: document.getElementById('kb-size'),
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    setupEventListeners();
});

function setupEventListeners() {
    ELEMENTS.queryInput.addEventListener('input', updateCharCount);
    ELEMENTS.submitBtn.addEventListener('click', handleSubmit);
    ELEMENTS.queryInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            handleSubmit();
        }
    });
}

function updateCharCount() {
    const count = ELEMENTS.queryInput.value.length;
    ELEMENTS.charCount.textContent = `${count}/500`;
    ELEMENTS.submitBtn.disabled = count === 0;
}

async function handleSubmit() {
    const query = ELEMENTS.queryInput.value.trim();

    if (!query) {
        showError('Please enter a question');
        return;
    }

    if (query.length > 500) {
        showError('Question is too long (max 500 characters)');
        return;
    }

    await submitQuestion(query);
}

async function submitQuestion(question) {
    // Update UI state
    ELEMENTS.queryInput.value = question;
    updateCharCount();
    ELEMENTS.submitBtn.disabled = true;
    hideError();
    showLoading();
    hideResults();
    hideSamples();

    try {
        const response = await fetch(`${API_BASE}/query`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query: question })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
        }

        if (data.status !== 'success') {
            throw new Error(data.error || 'Failed to generate answer');
        }

        displayResults(data);
        hideLoading();
        showResults();

    } catch (error) {
        showError(error.message || 'An error occurred. Please try again.');
        hideLoading();
    } finally {
        ELEMENTS.submitBtn.disabled = false;
    }
}

function displayResults(data) {
    // Display query
    ELEMENTS.displayedQuery.textContent = data.query;

    // Display context
    const { documents, similarities } = data.context;
    ELEMENTS.contextCount.textContent = documents.length;

    if (documents.length === 0) {
        ELEMENTS.contextContainer.innerHTML = '<p style="color: #6b7280;">No relevant context found in knowledge base.</p>';
    } else {
        ELEMENTS.contextContainer.innerHTML = documents.map((doc, idx) => `
            <div class="context-item">
                <p class="context-item-text">${escapeHtml(doc)}</p>
                <div class="context-item-meta">
                    <span>Document ${idx + 1}</span>
                    <span class="similarity-badge">Similarity: ${similarities[idx]}</span>
                </div>
            </div>
        `).join('');
    }

    // Display answer
    ELEMENTS.assistantAnswer.textContent = data.answer || 'No answer generated';

    // Display metadata
    ELEMENTS.metadataContainer.innerHTML = `
        <div class="metadata-item">
            <div class="metadata-label">Status</div>
            <div class="metadata-value">${capitalizeFirst(data.status)}</div>
        </div>
        <div class="metadata-item">
            <div class="metadata-label">Context Chunks</div>
            <div class="metadata-value">${data.context.count}</div>
        </div>
        <div class="metadata-item">
            <div class="metadata-label">Timestamp</div>
            <div class="metadata-value">${formatDate(data.timestamp)}</div>
        </div>
        <div class="metadata-item">
            <div class="metadata-label">Retrieval Method</div>
            <div class="metadata-value">Cosine Similarity</div>
        </div>
    `;
}

function showLoading() {
    ELEMENTS.loadingState.classList.remove('hidden');
}

function hideLoading() {
    ELEMENTS.loadingState.classList.add('hidden');
}

function showResults() {
    ELEMENTS.resultsSection.classList.remove('hidden');
}

function hideResults() {
    ELEMENTS.resultsSection.classList.add('hidden');
}

function showError(message) {
    ELEMENTS.errorMessage.textContent = message;
    ELEMENTS.errorState.classList.remove('hidden');
}

function hideError() {
    ELEMENTS.errorState.classList.add('hidden');
}

function closeError() {
    hideError();
}

function hideSamples() {
    ELEMENTS.samplesSection.classList.add('hidden');
}

function showSamples() {
    ELEMENTS.samplesSection.classList.remove('hidden');
}

async function loadStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        const data = await response.json();
        ELEMENTS.kbSize.textContent = `📚 Knowledge Base: ${data.knowledge_base_size} documents`;
    } catch (error) {
        console.warn('Failed to load stats:', error);
    }
}

// Utility functions
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatDate(isoString) {
    const date = new Date(isoString);
    return date.toLocaleTimeString();
}
